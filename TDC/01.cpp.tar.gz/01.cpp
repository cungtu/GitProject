#include <iostream>
// bai tim so doi xung trong khoang 10000>n>=1000
using namespace std;
int main()
{
	int d,t,n;
	cin>>n;
	d=0;
	t=n;
	if (10000>n>=1000){
		
		while (t>=1){
			d=d*10+t%10;
			t=(t-t%10)/10;
		
		if (d==n){
			cout<<"DX\n";
			}
		else{
			cout<<"KDX\n";
				}}}
		
	else{
		cout<<"-1";
	}
	return 0;
}

