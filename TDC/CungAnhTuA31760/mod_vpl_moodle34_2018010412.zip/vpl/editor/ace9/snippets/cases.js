ace.define("ace/snippets/cases",
                [ "require", "exports", "module" ],
                function(e, t, n) {
                    "use strict";
                            t.snippetText = '\nsnippet Basic\nCase = ${1:Name}\nInpunt = ${2:Program input}\nOutput = ${3:Expeted output}\n',
                            t.scope = "cases"
                })